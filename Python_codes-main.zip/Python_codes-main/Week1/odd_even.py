a = 1;
print(a%2)
b = 3;
if (a%2==0):
    print("even")
else:
    print("odd")
    
