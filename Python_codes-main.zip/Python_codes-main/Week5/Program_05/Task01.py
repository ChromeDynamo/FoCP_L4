import sys

def main():
    # Get the platform information
    platform = sys.platform
    
    # Print the platform information
    print(f"You are using the following operating system platform: {platform}")

if __name__ == "__main__":
    main()